// Deploy code

const MailService = require('@sendgrid/mail').MailService
const { MongoClient, ObjectId } = require('mongodb');
//const url = 'mongodb+srv://mf2-dev:kGdQhSTENXPJBbfc@mf2-dev.ttnel.mongodb.net/mf2-dev';
//const dbName = 'mf2-staging';
const dbName = 'mf2-dev';
const url = 'mongodb+srv://mf2-dev:kGdQhSTENXPJBbfc@mf2-dev.ttnel.mongodb.net/mf2-dev'
// import * as sendgrid from './sendgrid.cjs';
// import * as templates from './templates.cjs'
// import { MailService } from '@sendgrid/mail';

const client = new MongoClient(url);

const templates = {
    welcomeEmail: 'd-eb19ae82be664664bd749d2aef1f2bda',
    verifyEmail: 'd-7d5ff556a8174734b031ceb0187d5e50',
    subscriptionUpdated: 'd-3c11e71ec680403783fcd963d7b68ee9',
    trialWillEnd: 'd-17e44ed5e37d4928b687176d2cba57b5',
    accountBalanceUpdated: 'd-285cc108dfa24f84a942d2ef62c0e18c',
    developerInstructions: 'd-f39f7d5ddb5f47c7819ea4600391fb68',
    accountEmailChange: 'd-44384d55ad1948cdafadf643a0a07aed',
    accountDeletion: 'd-0987ee15f89547abb61eb0f119f097e5',
    accountPasswordChange: 'd-160b9333597a40ba8a514c1f695445d3',
    updateAccountPasswordRequest: `d-8cfc3d915e4243fcbb72c34c57585ef4`,
    passwordChangedSuccess: 'd-e7c27407d2484be49a37814d3bc6975e',
    firstFormIsPublished: 'd-b0d06701a9244aca81444fa84b388710',
    detachPaymentMethod: 'd-b0b43bea0b184c598bd9792e2bdba09d',
    regularPaymentNotReceivedInTime: 'd-1a4c8ff92ba645c3bd0f404b8ef20571',
    firstPaymentAfterPlanChanging: 'd-6dde82e4628249799c52b7ef8cbcca02',
    scheduledPaymentWasReceived: 'd-8665871592e84cfcb065b82a37b24b75',
    regularPaymentWasExpiredAt7Days: 'd-29725bad06a3412f80ee153c0e196159',
    welcomeToReferralProgram: `d-f2598b636c0b440c963cdebd828202bc`,
    thanksForRecommending: `d-c2c2914693734ef89ad1f11fd50e1a7a`,
    getReadyForRewards: `d-4c949710297b4d179398a8dc94d99a27`,
    shopifyWebhookUserDataRequest: `d-230ead10d479424a9935cdc0687fdefe`,
    gdprSendProjectsInZip: 'd-530076ba931b4af7ac5c6a9edf7b8d51',
    hourWithoutProjects: 'd-3f75e0710c68460a8f9f492985dbc03f',
}

const defaultMailer = new MailService();
const marketingMailer = new MailService();

marketingMailer.setApiKey('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');
defaultMailer.setApiKey('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');


async function checkingPlanLimits(submissionId, userId, projectId, sendType, dbCollectionsForNotifications){
}

async function main() {
  try{
    await client.connect();
    console.log('Connected successfully to server');
    const db = client.db(dbName);
    const projects = db.collection('projects');
    const planLimits = db.collection('planlimits')
    const submissions = db.collection('submissions')
    const notifications = db.collection('notifications')
    return { projects, planLimits, submissions, notifications };
  }catch(err){
    console.log('main err: ', err)
  }
}

async function sendProjectNotifications(data, sendType, type, collections){
  console.log('submission collection: ', data)
  const project_id = data?.project_id
  const projects = await collections.projects.find({ project_id }).toArray()
  console.log('project collection: ', projects[0])
}


exports.handler = async (event) => {
    console.log('Deploy test')
    const dbCollectionsForNotifications = await main();
    for( let { body } of event.Records){
        try {
            console.log('body: ', body)
            body = JSON.parse(body)
            let mailer = defaultMailer;
            if (body?.submissionReq === false){
                if (body?.templateId === templates.hourWithoutProjects) {
              mailer = marketingMailer;
                }
                return await mailer.send({
                  to: body?.emailTo,
                  from: {
                      email: body?.from,
                      name: 'MightyForms',
                  },
                  templateId: body?.templateId,
                  dynamicTemplateData: body?.templateData,
                  attachments: body?.attachments,
                });
            } else { 
              const submission = await dbCollectionsForNotifications.submissions.find({_id: ObjectId(body?.submissionId)}).toArray()
              if(!submission){
                return
              }
              console.log('submission before send notifications: ', submission[0])
              sendProjectNotifications(submission[0], 'submitted', '', dbCollectionsForNotifications)
            }
            
        } catch (err) {
            throw err;
        }
    }
};
